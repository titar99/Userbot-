import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "100"))

DEVS = list(map(int, os.getenv("DEVS", "5506568422").split()))

API_ID = int(os.getenv("API_ID", "25025641"))

API_HASH = os.getenv("API_HASH", "dafe19f097a35cc318cd3ebbadf12008")

BOT_TOKEN = os.getenv("BOT_TOKEN", "7733916850:AAGOFDD4ipFcFdx-E66-rHMWadD92LIRHdM")

OWNER_ID = int(os.getenv("OWNER_ID", "6635327336"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1002399953106").split()))

RMBG_API = os.getenv("RMBG_API", "a6qxsmMJ3CsNo7HyxuKGsP1o")

MONGO_URL = os.getenv("MONGO_URL", "")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT"))

USER_GROUP = os.getenv("USER_GROUP", "https://t.me/AunuHost")
